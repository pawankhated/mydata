<?php 

use \Illuminate\Database\Eloquent\Model as Eloquent;

class User extends Eloquent {

    protected $table = "employees"; // table name
    
    public function role(){
        return $this->hasOne('Role','role_id','role_id');
    }
}
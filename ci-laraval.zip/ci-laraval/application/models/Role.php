<?php 

use \Illuminate\Database\Eloquent\Model as Eloquent;

class Role extends Eloquent {

    protected $table = "role"; // table name
    protected $primaryKey = "role_id"; // table name
    
    public function user(){
        return $this->hasMany('User','role_id','role_id');
    }
    
}